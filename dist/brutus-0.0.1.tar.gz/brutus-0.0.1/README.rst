Brutus
======
When all you have is a hammer, every problem is a nail.

Relentlessly hammer away at a machine until your software runs.
